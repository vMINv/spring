package com.carshop.domain;

import org.springframework.stereotype.Controller;

@Controller
public class OrderController {
	//사용X 
}
