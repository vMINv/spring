package com.carshop.board;

import java.util.List;

public interface BoardService {

	List<BoardDTO> getAllBoardList();
}
