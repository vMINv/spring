package com.carshop.domain;

public interface OrderRepository {
	Long saveOrder(Order order);
}
